-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Servidor: localhost:3306
-- Tiempo de generación: 08-12-2018 a las 11:58:39
-- Versión del servidor: 5.7.23
-- Versión de PHP: 7.1.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `saludtech`
--
CREATE DATABASE IF NOT EXISTS `saludtech` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `saludtech`;

DELIMITER $$
--
-- Procedimientos
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_actualizarMedico` (IN `pIdMedico` INT, IN `pPrimerNombre` VARCHAR(50), IN `pSegundoNombre` VARCHAR(50), IN `pPrimerApellido` VARCHAR(50), IN `pSegundoApellido` VARCHAR(50), IN `pDocumento` VARCHAR(50), IN `pEspecialidad` VARCHAR(400), IN `pFechaNacimiento` DATE)  NO SQL
UPDATE config_medico
SET  primerNombre=pPrimerNombre,
	 segundoNombre=pSegundoNombre,
     primerApellido=pPrimerApellido,
     segundoApellido=pSegundoApellido,
     documento=pDocumento,
     especialidad=pEspecialidad,
     fechaNacimiento=pFechaNacimiento
WHERE idMedico=pIdMedico$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_actualizarServicio` (IN `pIdServicio` INT, IN `pDescripcion` VARCHAR(400))  NO SQL
UPDATE config_servicio
SET  descripcion=pDescripcion
WHERE idServicio=pIdServicio$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_actualizarTarifa` (IN `pIdTarifa` INT, IN `pIdServicio` INT, IN `pIdMedico` INT, IN `pPrecio` FLOAT)  NO SQL
UPDATE config_servicio_medico 
SET idServicio=pIdServicio, 
	idMedico=pIdMedico,
    precio=pPrecio
WHERE idTarifa=pIdTarifa$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_actualizarUsuario` (IN `pIdUsuario` INT, IN `pEmail` VARCHAR(100), IN `pClave` VARCHAR(100))  NO SQL
UPDATE config_usuario 
SET  email=pEmail,
	 clave=pClave
WHERE idUsuario=pIdUsuario$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_anularMedico` (IN `pIdMedico` INT)  NO SQL
UPDATE config_medico
SET  estado=1
WHERE idMedico=pIdMedico$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_anularServicio` (IN `pIdServicio` INT)  NO SQL
UPDATE config_servicio
SET  estado=1
WHERE idServicio=pIdServicio$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_anularTarifa` (IN `pIdTarifa` INT)  NO SQL
UPDATE config_servicio_medico 
SET estado=1
WHERE idTarifa=pIdTarifa$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_anularUsuario` (IN `pIdUsuario` INT)  NO SQL
UPDATE config_usuario 
SET  estado=1
WHERE idUsuario=pIdUsuario$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_crearMedico` (IN `pPrimerNombre` VARCHAR(50), IN `pSegundoNombre` VARCHAR(50), IN `pPrimerApellido` VARCHAR(50), IN `pSegundoApellido` VARCHAR(50), IN `pDocumento` VARCHAR(50), IN `pEspecialidad` VARCHAR(400), IN `pFechaNacimiento` DATE)  NO SQL
BEGIN
  INSERT INTO config_medico (primerNombre, segundoNombre,primerApellido,segundoApellido,documento,especialidad,fechaNacimiento,estado) VALUES (pPrimerNombre, pSegundoNombre,pPrimerApellido,pSegundoApellido,pDocumento,pEspecialidad,pFechaNacimiento,0);
 END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_crearServicio` (IN `pIdCategoria` INT, IN `pDescripcion` VARCHAR(400))  NO SQL
BEGIN
  INSERT INTO config_servicio (idCategoria,descripcion,estado) VALUES (pIdCategoria,pDescripcion,0);
 END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_crearTarifa` (IN `pIdServicio` INT, IN `pIdMedico` INT, IN `pPrecio` FLOAT)  NO SQL
BEGIN
  INSERT INTO config_servicio_medico (idServicio, idMedico,precio,estado) 	VALUES (pIdServicio,pIdMedico, pPrecio,0);
 END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_crearUsuario` (IN `pusuario` VARCHAR(30), IN `pemail` VARCHAR(100), IN `pclave` VARCHAR(100), IN `pTipo` INT)  BEGIN
  INSERT INTO config_usuario (nombre, email,clave,tipo,estado) VALUES (pusuario, pemail,pclave,pTipo,0);
 END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_listarCategoria` ()  NO SQL
SELECT * FROM config_categoria_servicio
WHERE estado=0
order by 1$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_listarServicio` ()  NO SQL
SELECT cs.idServicio, cs.descripcion, ccs.idCategoria 
FROM config_categoria_servicio ccs JOIN config_servicio cs 
ON ccs.idCategoria=cs.idCategoria and  ccs.estado=0 and cs.estado=0
order by 1$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_listarTarifa` ()  NO SQL
SELECT csm.idtarifa,
	   cs.descripcion,
       concat(cm.primerNombre ,' ', cm.segundoNombre ,' ', cm.primerApellido ,' ',cm.segundoApellido) 'Médico',
       csm.precio
FROM config_servicio_medico csm JOIN config_servicio cs
on csm.idServicio=cs.idServicio and csm.estado=0 and cs.estado=0 JOIN config_medico cm
on csm.idMedico=cm.idMedico and cm.estado=0
order by 1$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_listarUsuario` ()  NO SQL
SELECT idUsuario,
	   nombre,
       email,
       tipo
FROM config_usuario
WHERE estado=0
order by 1$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_verificarUsuario` (IN `pNombre` VARCHAR(30), OUT `pIdusuario` INT, OUT `pClave` VARCHAR(100))  NO SQL
SELECT idUsuario, clave into pIdUsuario,pClave FROM config_usuario
WHERE nombre collate utf8_spanish_ci=pNombre and estado=0$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `admin_factura`
--

CREATE TABLE `admin_factura` (
  `idFactura` int(11) NOT NULL,
  `idMedioPago` int(11) NOT NULL,
  `comprobante` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `admin_pago`
--

CREATE TABLE `admin_pago` (
  `idPago` int(11) NOT NULL,
  `idReserva` int(11) NOT NULL,
  `idFactura` int(11) NOT NULL,
  `fecha` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `admin_reserva`
--

CREATE TABLE `admin_reserva` (
  `idReserva` int(11) NOT NULL,
  `idUsuario` int(11) NOT NULL,
  `fecha` datetime NOT NULL,
  `estado` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `admin_reserva_servicio`
--

CREATE TABLE `admin_reserva_servicio` (
  `idReserva` int(11) NOT NULL,
  `idTarifa` int(11) NOT NULL,
  `fechaConsulta` datetime NOT NULL,
  `estado` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `config_categoria_servicio`
--

CREATE TABLE `config_categoria_servicio` (
  `idCategoria` int(11) NOT NULL,
  `descripcion` varchar(100) NOT NULL,
  `estado` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `config_categoria_servicio`
--

INSERT INTO `config_categoria_servicio` (`idCategoria`, `descripcion`, `estado`) VALUES
(1, 'Medicina general', 0),
(2, 'Urgencia', 0),
(3, 'Estetica', 0),
(4, 'Medicina especializada', 0),
(5, 'Cirugía', 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `config_medico`
--

CREATE TABLE `config_medico` (
  `idMedico` int(11) NOT NULL,
  `primerNombre` varchar(50) NOT NULL,
  `segundoNombre` varchar(50) NOT NULL,
  `primerApellido` varchar(50) NOT NULL,
  `segundoApellido` varchar(50) NOT NULL,
  `documento` varchar(100) NOT NULL,
  `especialidad` varchar(100) NOT NULL,
  `fechaNacimiento` date NOT NULL,
  `estado` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `config_medico`
--

INSERT INTO `config_medico` (`idMedico`, `primerNombre`, `segundoNombre`, `primerApellido`, `segundoApellido`, `documento`, `especialidad`, `fechaNacimiento`, `estado`) VALUES
(1, 'jorge', 'andres', 'lugo', 'meza', '123456789', 'neonatos', '1975-10-11', 0),
(2, 'Orlando', 'Javier', 'Bastista', 'Zuñiga', '123123123', 'pediatra', '1986-06-07', 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `config_servicio`
--

CREATE TABLE `config_servicio` (
  `idServicio` int(11) NOT NULL,
  `descripcion` varchar(400) NOT NULL,
  `idCategoria` int(11) NOT NULL,
  `estado` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `config_servicio`
--

INSERT INTO `config_servicio` (`idServicio`, `descripcion`, `idCategoria`, `estado`) VALUES
(1, 'Acupuntura', 3, 0),
(2, 'Cirugía estetica', 3, 0),
(3, 'Fisioterapia', 3, 0),
(4, 'Medicina estética', 3, 0),
(5, 'Medicina general', 1, 0),
(6, 'Alergología', 4, 0),
(7, 'Dermatologia', 4, 0),
(8, 'Nefrología', 4, 0),
(9, 'Neumología', 4, 0),
(10, 'Neurología', 4, 0),
(11, 'Psiquiatria', 4, 0),
(12, 'Reumatología', 4, 0),
(13, 'Urgencia domiciliaria', 2, 0),
(14, 'Urgencia ginecológica', 2, 0),
(15, 'Abdominoplastia', 5, 0),
(16, 'Mamoplastia', 5, 0),
(17, 'Liposucción', 5, 0),
(18, 'Cataratas', 5, 0),
(19, 'Hemorroides', 5, 0),
(20, '', 2, 0),
(21, 'Cirugía maxilar', 2, 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `config_servicio_medico`
--

CREATE TABLE `config_servicio_medico` (
  `idtarifa` int(11) NOT NULL,
  `idServicio` int(11) NOT NULL,
  `idMedico` int(11) NOT NULL,
  `precio` float NOT NULL,
  `estado` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `config_servicio_medico`
--

INSERT INTO `config_servicio_medico` (`idtarifa`, `idServicio`, `idMedico`, `precio`, `estado`) VALUES
(1, 15, 1, 150000, 0),
(2, 1, 1, 155000, 0),
(3, 6, 1, 185000, 0),
(4, 18, 1, 174000, 0),
(5, 2, 1, 5800000, 0),
(6, 7, 1, 190000, 0),
(7, 5, 1, 50000, 0),
(8, 4, 1, 120000, 0),
(9, 13, 1, 85000, 0),
(10, 21, 1, 345000, 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `config_usuario`
--

CREATE TABLE `config_usuario` (
  `idUsuario` int(11) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `clave` varchar(100) NOT NULL,
  `tipo` int(11) NOT NULL,
  `estado` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `config_usuario`
--

INSERT INTO `config_usuario` (`idUsuario`, `nombre`, `email`, `clave`, `tipo`, `estado`) VALUES
(14, 'jmeza', 'juliomeza@gmail.com', 'pbkdf2:sha256:50000$WMFSlyyc$45b5763e9bc3b7f5af93b5d5a38de464758131803253e7aec0a743f69b69765a', 0, 0),
(15, 'orlando', 'orlando@gmail.com', 'pbkdf2:sha256:50000$BfaWV5vN$550c56bdc683e91527552fa60d4b5f57d0d7441fdcaecffae9ac6e19e8a21ba8', 0, 0),
(16, 'manuel', 'manuel@gmail.com', 'pbkdf2:sha256:50000$gv9WyOGa$4ad99e98badc472455680b2aaf1204d79ce60da92fc9bf3c17e6685b702de550', 0, 0),
(17, 'angel', 'angel@gmail.com', 'pbkdf2:sha256:50000$J2CfRLVk$1015ca474284db71a26cb8a203786f31867e9e3e1bace17ccd39aa2f1d62f21d', 0, 0),
(18, 'admin', 'admin@gmail.com', 'pbkdf2:sha256:50000$SbR3dWgS$2b0e9d4b87cffc2f87d14d211610e060a67d133c0ee2c05dfa1c684f6b1bb3df', 100, 0),
(19, 'andres', 'adminandres@gmail.com', 'pbkdf2:sha256:50000$KgWzZebC$da60fff126a2871df95658b25b7fb214e716de4be5ced2ad9d4b678dda328349', 1, 0),
(20, 'marbel', 'marbel@gmail.com', 'pbkdf2:sha256:50000$fXxfJvDl$039c091c4e69a6e30ad083920b77a469b880966d0fa210a94237838397633246', 0, 0),
(21, 'lilibeth', 'lilibeth@gmail.com', 'pbkdf2:sha256:50000$AiwfOLjS$d54240e5b4ee51059e30fa0441929e2b38b77a963e52cab1c1671189033dd0aa', 0, 0),
(22, 'obatista', 'orlandoB@gmail.com', 'pbkdf2:sha256:50000$BAmgrqQk$94ac628081c4c7b989f2843d063ccf6c9bc18b2e6cc15ec8d371aa199e1717e1', 1, 0);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `admin_factura`
--
ALTER TABLE `admin_factura`
  ADD PRIMARY KEY (`idFactura`);

--
-- Indices de la tabla `admin_pago`
--
ALTER TABLE `admin_pago`
  ADD PRIMARY KEY (`idPago`),
  ADD KEY `idFactura` (`idFactura`),
  ADD KEY `idReserva` (`idReserva`);

--
-- Indices de la tabla `admin_reserva`
--
ALTER TABLE `admin_reserva`
  ADD PRIMARY KEY (`idReserva`),
  ADD KEY `idUsuario` (`idUsuario`);

--
-- Indices de la tabla `admin_reserva_servicio`
--
ALTER TABLE `admin_reserva_servicio`
  ADD KEY `idTarifa` (`idTarifa`),
  ADD KEY `idReserva` (`idReserva`);

--
-- Indices de la tabla `config_categoria_servicio`
--
ALTER TABLE `config_categoria_servicio`
  ADD PRIMARY KEY (`idCategoria`);

--
-- Indices de la tabla `config_medico`
--
ALTER TABLE `config_medico`
  ADD PRIMARY KEY (`idMedico`);

--
-- Indices de la tabla `config_servicio`
--
ALTER TABLE `config_servicio`
  ADD PRIMARY KEY (`idServicio`),
  ADD KEY `idCategoria` (`idCategoria`);

--
-- Indices de la tabla `config_servicio_medico`
--
ALTER TABLE `config_servicio_medico`
  ADD PRIMARY KEY (`idtarifa`),
  ADD KEY `idMedico` (`idMedico`),
  ADD KEY `idServicio` (`idServicio`);

--
-- Indices de la tabla `config_usuario`
--
ALTER TABLE `config_usuario`
  ADD PRIMARY KEY (`idUsuario`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `admin_factura`
--
ALTER TABLE `admin_factura`
  MODIFY `idFactura` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `admin_pago`
--
ALTER TABLE `admin_pago`
  MODIFY `idPago` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `admin_reserva`
--
ALTER TABLE `admin_reserva`
  MODIFY `idReserva` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `config_categoria_servicio`
--
ALTER TABLE `config_categoria_servicio`
  MODIFY `idCategoria` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `config_medico`
--
ALTER TABLE `config_medico`
  MODIFY `idMedico` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `config_servicio`
--
ALTER TABLE `config_servicio`
  MODIFY `idServicio` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT de la tabla `config_servicio_medico`
--
ALTER TABLE `config_servicio_medico`
  MODIFY `idtarifa` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT de la tabla `config_usuario`
--
ALTER TABLE `config_usuario`
  MODIFY `idUsuario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `admin_pago`
--
ALTER TABLE `admin_pago`
  ADD CONSTRAINT `admin_pago_ibfk_1` FOREIGN KEY (`idFactura`) REFERENCES `admin_factura` (`idFactura`),
  ADD CONSTRAINT `admin_pago_ibfk_2` FOREIGN KEY (`idReserva`) REFERENCES `admin_reserva` (`idReserva`);

--
-- Filtros para la tabla `admin_reserva`
--
ALTER TABLE `admin_reserva`
  ADD CONSTRAINT `admin_reserva_ibfk_1` FOREIGN KEY (`idUsuario`) REFERENCES `config_usuario` (`idUsuario`);

--
-- Filtros para la tabla `admin_reserva_servicio`
--
ALTER TABLE `admin_reserva_servicio`
  ADD CONSTRAINT `admin_reserva_servicio_ibfk_1` FOREIGN KEY (`idTarifa`) REFERENCES `config_servicio_medico` (`idtarifa`),
  ADD CONSTRAINT `admin_reserva_servicio_ibfk_2` FOREIGN KEY (`idReserva`) REFERENCES `admin_reserva` (`idReserva`);

--
-- Filtros para la tabla `config_servicio`
--
ALTER TABLE `config_servicio`
  ADD CONSTRAINT `config_servicio_ibfk_1` FOREIGN KEY (`idCategoria`) REFERENCES `config_categoria_servicio` (`idCategoria`);

--
-- Filtros para la tabla `config_servicio_medico`
--
ALTER TABLE `config_servicio_medico`
  ADD CONSTRAINT `config_servicio_medico_ibfk_1` FOREIGN KEY (`idMedico`) REFERENCES `config_medico` (`idMedico`),
  ADD CONSTRAINT `config_servicio_medico_ibfk_2` FOREIGN KEY (`idServicio`) REFERENCES `config_servicio` (`idServicio`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
